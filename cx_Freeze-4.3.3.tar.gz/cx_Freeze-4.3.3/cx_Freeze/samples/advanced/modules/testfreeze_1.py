# -*- coding: utf-8 -*-

import sys

sys.stdout.write('Test freeze module #1\n')
